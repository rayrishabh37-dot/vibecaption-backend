# VibeCaption AI — Real AI-ready prototype

## What it does
A small web app for generating original Instagram/Reels captions from a song/topic, style and preferred opening.

## How the AI works
The browser calls `/api/generate`. The server calls OpenAI's Responses API. The API key stays on the server in an environment variable.

## Run
1. Install Node.js.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env`.
4. Put your API key in `.env`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

Without an API key, the app runs in demo mode so the UI can still be tested.

## Business idea
Free: limited generations.
Pro: more generations + saved captions + creator tools.
Do not promise users guaranteed income.

## Important
ChatGPT subscriptions and API billing are separate. API usage can incur separate charges.
For a real public launch, add authentication, rate limits, abuse protection, logging, a database and a payment/subscription system.
