import express from "express";
import OpenAI from "openai";

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: "20kb" }));
app.use(express.static("public"));

const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.post("/api/generate", async (req, res) => {
  try {
    const { topic, style = "Aesthetic", opening = "Tonight", count = 5 } = req.body || {};
    if (!topic || typeof topic !== "string") {
      return res.status(400).json({ error: "Please enter a song or topic." });
    }

    // Demo mode lets the UI work before an API key is configured.
    if (!client) {
      const demo = [
        `${opening === "Any" ? "" : opening + ", "}${topic} — and suddenly the whole mood makes sense.`,
        `POV: ${topic}, but make it a feeling.`,
        `${topic}, on repeat.`,
        `Some moments deserve ${topic} as their soundtrack.`,
        `No explanation. Just ${topic}.`
      ];
      return res.json({ captions: demo.slice(0, Math.max(1, Math.min(5, count))), demo: true });
    }

    const response = await client.responses.create({
      model: "gpt-5.5",
      instructions:
        "You are VibeCaption AI, a concise social-media copy assistant. " +
        "Generate original, non-lyrical captions for short-form videos. " +
        "Never reproduce song lyrics. Keep captions natural, modern and safe. " +
        "Return exactly one caption per line and no numbering.",
      input:
        `Song/topic: ${topic}\nStyle: ${style}\nPreferred opening: ${opening}\n` +
        `Generate ${Math.max(1, Math.min(5, count))} short Instagram/Reels captions.`
    });

    const captions = response.output_text
      .split("\n")
      .map(s => s.replace(/^\s*[-•*\d.)]+\s*/, "").trim())
      .filter(Boolean)
      .slice(0, 5);

    res.json({ captions, demo: false });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Generation failed. Please try again." });
  }
});

app.listen(port, () => console.log(`VibeCaption AI running on http://localhost:${port}`));
